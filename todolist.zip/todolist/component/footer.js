Vue.component('foot',{
    template:`
        <footer class="footer">
            <span class="todo-count">
                <strong>{{n}}</strong>
                <span>条未选中</span>
            </span>
            <ul class="filters">
                <li v-for="(val,key) in btns">
                    <a 
                        :href="val.hash"
                        :class="{selected:(cn == val.hash)}"
                    >{{val.name}}</a>
                </li>
            </ul>
        </footer>
    `,
    props:['n','cn'],
    data(){
        return {
            btns:[
                {
                    hash:'#/all',
                    name:'全部'
                },
                {
                    hash:'#/unchecked',
                    name:'未选中'
                },
                {
                    hash:'#/checked',
                    name:'已选中'
                }
            ]
        }
    },
    methods:{
        // hashchange(hash){
        //     this.$emit('hashc',hash)
        // }
    }
});