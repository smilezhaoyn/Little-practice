Vue.component('list',{
    props:['ary'],
    template:`
        <ul class="todo-list">
            <li 
                v-for="(val,key) in ary"
                :class="{completed:val.checked}">
                <div class="view">
                    <input class="toggle" type="checkbox" 
                    v-model="val.checked"
                    >
                    <label>{{val.text}}</label>
                    <button class="destroy"
                        @click="del(val.id)"
                    ></button>
                </div>
                <!-- <input class="edit" value="多多对对对"> -->
            </li>
        </ul>
    `,
    data(){
        return {
            filter:[]
        }
    },
    methods:{
        del(id){
            this.$emit('rm',id)
            // console.log(id)
        }
    }
    
})